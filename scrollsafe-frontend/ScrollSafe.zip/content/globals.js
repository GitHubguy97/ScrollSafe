(() => {
  window.ScrollSafe = window.ScrollSafe || {};
  window.ScrollSafe.adapters = window.ScrollSafe.adapters || [];
})();

